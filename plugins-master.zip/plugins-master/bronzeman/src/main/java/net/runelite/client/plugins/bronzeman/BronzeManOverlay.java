package net.runelite.client.plugins.bronzeman;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.inject.Inject;
import net.runelite.api.Client;
import net.runelite.api.GameState;
import net.runelite.client.game.ItemManager;
import net.runelite.client.ui.overlay.Overlay;
import net.runelite.client.ui.overlay.OverlayPosition;


/**
 * @author Seth Davis
 * @Email <sethdavis321@gmail.com>
 * @Discord Reminisce#1707
 */
public class BronzeManOverlay extends Overlay
{

	private final Client client;
	private final BronzemanPlugin plugin;
	private final BronzeManConfig config;
	private final List<ItemUnlock> itemUnlockList;
	private ItemUnlock currentUnlock;
	@Inject
	private ItemManager itemManager;

	@Inject
	public BronzeManOverlay(final Client client, final BronzemanPlugin plugin, final BronzeManConfig config)
	{
		this.client = client;
		this.plugin = plugin;
		this.config = config;
		this.itemUnlockList = new CopyOnWriteArrayList<>();
		setPosition(OverlayPosition.TOP_CENTER);
	}

	void addItemUnlock(int itemId)
	{
		itemUnlockList.add(new ItemUnlock(itemId));
	}

	@Override
	public Dimension render(Graphics2D graphics)
	{
		if (client.getGameState() != GameState.LOGGED_IN || !config.notifyImgUnlock() || itemUnlockList.isEmpty() || itemManager == null)
		{
			return null;
		}

		if (currentUnlock == null)
		{
			currentUnlock = itemUnlockList.get(0);
			currentUnlock.display();
			return null;
		}

		int drawY = currentUnlock.getLocationY();
		// Drawing unlock pop-up in a static location because this is how the game-mode is.
		graphics.drawImage(plugin.getUnlockImage(), -62, drawY, null);
		graphics.drawImage(getImage(currentUnlock.getItemId()), -50, drawY + 7, null);
		if (drawY < 10)
		{
			currentUnlock.setLocationY(drawY + 1);
		}
		if (currentUnlock.displayed(itemUnlockList.size()))
		{
			itemUnlockList.remove(currentUnlock);
			currentUnlock = null;
		}
		return null;
	}

	private BufferedImage getImage(int itemID)
	{
		return itemManager.getImage(itemID, 1, false);
	}

}
