package net.runelite.client.plugins.banlist;

public enum ListType
{
	WEDORAIDSSCAM_LIST,
	WEDORAIDSTOXIC_LIST,
	RUNEWATCH_LIST,
	MANUAL_LIST
}
